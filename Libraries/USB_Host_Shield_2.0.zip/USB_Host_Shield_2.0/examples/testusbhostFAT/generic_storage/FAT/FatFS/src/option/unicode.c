#include <FAT/FatFS/src/ff.h>

#if _USE_LFN != 0

#include <FAT/FatFS/src/option/cc932.c>
#include <FAT/FatFS/src/option/cc936.c>
#include <FAT/FatFS/src/option/cc949.c>
#include <FAT/FatFS/src/option/cc950.c>
#include <FAT/FatFS/src/option/ccsbcs.c>
#endif
